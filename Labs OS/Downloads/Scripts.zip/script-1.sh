#!/bin/bash
echo " Hello World"

# Script to print user information who currently login , current date and time
echo " Hello $USER"

