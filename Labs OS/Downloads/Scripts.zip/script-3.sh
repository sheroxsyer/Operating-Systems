#!/bin/bash
echo "Script for Command Line Arguments"
x=$1
y=$3

k=$(( $x + $y ))
echo "sum is:$k" 
exit 0