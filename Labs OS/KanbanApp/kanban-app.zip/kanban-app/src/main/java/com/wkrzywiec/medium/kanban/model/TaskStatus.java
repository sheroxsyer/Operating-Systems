package com.wkrzywiec.medium.kanban.model;

import io.swagger.annotations.ApiModel;

@ApiModel
public enum TaskStatus {
    TODO, INPROGRESS, DONE
}
