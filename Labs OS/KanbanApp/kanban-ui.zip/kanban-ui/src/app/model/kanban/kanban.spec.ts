import { Kanban } from './kanban';

describe('Kanban', () => {
  it('should create an instance', () => {
    expect(new Kanban()).toBeTruthy();
  });
});
