export const environment = {
  production: true,
  kanbanAppUrl: '/api'
};
